import { QueryBuildDirectiveDirective } from './query-build-directive.directive';

describe('QueryBuildDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new QueryBuildDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
