import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, FormArray } from '@angular/forms';

@Component({
  selector: 'app-condition-build',
  templateUrl: './condition-build.component.html',
  styleUrls: ['./condition-build.component.css']
})
export class ConditionBuildComponent implements OnInit {
    addConditionForm: FormGroup;
    conditions: FormArray;
    groups: FormArray;
    conditionvalue: any;
    conditionoperator: any;
    buttonDisabled: true;
    buttonDisabled1: true;
    
    constructor(private fb: FormBuilder) { }
   

    ngOnInit() {
        this.conditionvalue = [
            { id: 1, value: "a" },
            { id: 2, value: "b" }
        ];
        this.conditionoperator = [
            { id: 1, operator: ">" },
            { id: 2, operator: ">=" },
            { id: 3, operator: "<" },
             { id: 4, operator: "<=" },
              { id: 5, operator: "=" }
        ];

        
        
        this.addConditionForm = this.fb.group({
           
            conditions: this.fb.array([
                this.addCondition(),
                 
            ]), 
            //groups: this.fb.array([
           //     this.addGroup()
           // ])
        });
       
       
    }


    getValue(e){
      console.log(e);
    }
    addGroup(): FormGroup {
        console.log(this.fb.group);

        return this.fb.group({
            //val3: new FormControl(""),
            //val4: new FormControl(""),
            //val5: new FormControl("")
            conditions: this.fb.array([
                this.addCondition()
            ])
        });
    }


   
    addCondition(): FormGroup {
        return this.fb.group({
            conditions:{
              val: '',
              val1: '',
              val2: '',
            },
            group: this.fb.array([])            
        })
            
            
    }
    addConditions(): FormGroup {
        return this.fb.group({
          conditions:{
            val: '',
            val1: '',
            val2: '',
          },

        })


    }
    addConditionclick() {

        console.log(this.addConditionForm);

       
       // console.log(i);
        //const control = (<FormArray>this.addConditionForm.get('conditions'));
        //control.insert(i, this.addCondition());
       // control.controls.indexOf(.push(this.addCondition());
        (<FormArray>this.addConditionForm.get('conditions')).push(this.addConditions());
    }

    addConditionclickSub(i,j) {

        console.log(this.addConditionForm);


        // console.log(i);
        //const control = (<FormArray>this.addConditionForm.get('conditions'));
        //control.insert(i, this.addCondition());
        // control.controls.indexOf(.push(this.addCondition());
        (((<FormArray>this.addConditionForm.get('conditions')).at(i).get('group') as FormArray).at(j).get('val3') as FormArray).push(this.addConditions());
    }


    
    addGroupclick(i) {
        console.log(i);
        ((<FormArray>this.addConditionForm.get('conditions')).at(i).get('group') as FormArray).push(this.addCondition());
    }
    addGroupclickSub(i,j) {
        console.log(i);
        (((<FormArray>this.addConditionForm.get('conditions')).at(i).get('group') as FormArray).at(j).get('val3') as FormArray).push(this.addCondition());
    }
    removeCondition(conditionIndex: number) {
        (<FormArray>this.addConditionForm.get('conditions')).removeAt(conditionIndex);
    }
    removeGroup(GroupIndex: number) {
        (<FormArray>this.addConditionForm.get('groups')).removeAt(GroupIndex);
    }
  }


