import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConditionBuildComponent } from './condition-build.component';

describe('ConditionBuildComponent', () => {
  let component: ConditionBuildComponent;
  let fixture: ComponentFixture<ConditionBuildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConditionBuildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConditionBuildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
