import { Directive } from '@angular/core';

@Directive({
  selector: '[appQueryBuildDirective]'
})
export class QueryBuildDirectiveDirective {

  constructor() { }

}
