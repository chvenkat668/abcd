import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.css']
})
export class EditorComponent implements OnInit {
  editorOptions = { theme: 'vs-dark', language: 'sql' };
  code = 'SELECT * FROM Table_1';

  ngOnInit(){

  }
  onInit(editor) {
    const monaco = window['monaco'];
    monaco.languages.registerCompletionItemProvider('sql', this.getSqlCompletionProvider(monaco));
  }

  getSqlCompletionProvider(monaco) {
    return {
      provideCompletionItems: function (model, position) {
        const completionItems = [
          {
            label: 'SELECT',
            kind: monaco.languages.CompletionItemKind.Keyword,
            detail: 'aSQL',
            documentation: 'asql selector.'
          },
          {
            label: 'abcd',
            kind: monaco.languages.CompletionItemKind.Keyword,
            detail: 'SQL',
            documentation: 'sql selector.'
          },
          {
            label: 'a',
            kind: monaco.languages.CompletionItemKind.Keyword,
            detail: 'SQL',
            documentation: 'sql selector.'
          },
          {
            label: 'c',
            kind: monaco.languages.CompletionItemKind.Keyword,
            detail: 'SQL',
            documentation: 'sql selector.'
          },
          {
            label: 'eead',
            kind: monaco.languages.CompletionItemKind.Keyword,
            detail: 'SQL',
            documentation: 'sql selector.'
          },
          {
            label: 'aSELECT',
            kind: monaco.languages.CompletionItemKind.Keyword,
            detail: 'SQL',
            documentation: 'sql selector.'
          }
        ];
        return completionItems;
      }
    };
  }

}
