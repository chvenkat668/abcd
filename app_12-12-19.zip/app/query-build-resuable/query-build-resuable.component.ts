import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
  @Component({
  selector: 'app-query-build-resuable',
  templateUrl: './query-build-resuable.component.html',
  styleUrls: ['./query-build-resuable.component.css']
})
export class QueryBuildResuableComponent implements OnInit {
  options=[
    1,2,3,4
  ];
  options2=[
    5,6,7,8
  ];
  optionSelected1:any;
  optionSelected2:any;
  constructor() { }
  @Input() list:any;
  @Input() aindex:any;
  @Output() groupRecords: EventEmitter<any> = new EventEmitter();
  // @Output() addGroup: EventEmitter<any> = new EventEmitter();
  // @Output() removeGroup: EventEmitter<any> = new EventEmitter();
  
  ngOnInit() {
    console.log(this.list)
  }
 
  getCondition(){
    return {
      val1:'',
      val2:'',
      val3:'',
    }
  }
  getGroup(){
    return [];
   
  }
  addCondition(ruleIndex){
      this.list.rules.push({'condition':this.getCondition()})      
  }
  onGroupRecords(obj){
    this.groupRecords.emit(obj);
  }
  addGroup(){
    const rules= [{'group':this.getGroup()}]    
    this.list.rules.push({'rules':rules})
  }
  removeCondition(i){
    this.list.rules.splice(i,1);
  }
}
