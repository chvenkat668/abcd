import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QueryBuildResuableComponent } from './query-build-resuable.component';

describe('QueryBuildResuableComponent', () => {
  let component: QueryBuildResuableComponent;
  let fixture: ComponentFixture<QueryBuildResuableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QueryBuildResuableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QueryBuildResuableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
