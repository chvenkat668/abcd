import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'custom-autocomplete-lib',
  template: `
    <p>
      autocomplete-lib works!
    </p>
  `,
  styles: []
})
export class AutocompleteLibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
