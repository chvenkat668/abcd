import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-query-build',
  templateUrl: './query-build.component.html',
  styleUrls: ['./query-build.component.css']
})
export class QueryBuildComponent implements OnInit {

  constructor() { }
  list:any;
  ngOnInit() {
    this.list={
      rules:[       
        {
          condition: this.getCondition(),
        }
      ]
    }
    console.log(this.list)
  }
  getRun(){
    console.log(this.list);
  }
  getClear(){
    this.list={
        rules:[       
        {
          condition: this.getCondition(),
        }
      ]
    }
  }
  getCondition(){
    return {
      val1:'',
      val2:'',
      val3:'',
    }
  }
  getGroup(){
    return [];
    //   condition:this.getCondition(),
    //   group:[]
    // }
  }
  groupRecords(obj){
    console.log(this.list);
   // this.list[obj.index]=obj.records;
    console.log(obj);    
  }
  // addCondition(ruleIndex){
  //   if(ruleIndex){
  //     this.list.rules.push({'condition':this.getCondition()})
  //   }
  //   else{
  //     this.list.rules.push({'condition':this.getCondition()})
  //   }
  // }
  // addGroup(){
  //   const rules= [ {'group':this.getGroup()}]
    
  //   this.list.rules.push({'rules':rules})
  //   console.log(this.list);
  // }
  // removeCondition(i){
  //   this.list.rules.splice(i,1);
  // }
}
