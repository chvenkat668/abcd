import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QueryBuildComponent } from './query-build.component';

describe('QueryBuildComponent', () => {
  let component: QueryBuildComponent;
  let fixture: ComponentFixture<QueryBuildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QueryBuildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QueryBuildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
