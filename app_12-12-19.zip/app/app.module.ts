import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {AutocompleteLibModule} from './auto-complete';

import {HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AppRoutingModule} from './app-routing.module';
import {HomeComponent} from './home/home.component';
import { QueryBuildComponent } from './query-build/query-build.component';
import { QueryBuildLevelComponent} from './query-build-resuable/query-build-level.component';
import {QueryBuildResuableComponent } from './query-build-resuable/query-build-resuable.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    QueryBuildComponent,
    QueryBuildLevelComponent,
    QueryBuildResuableComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AutocompleteLibModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
