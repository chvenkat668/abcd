import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-query-build-level',
  templateUrl: './query-build-resuable.component.html',
  styleUrls: ['./query-build-resuable.component.css']
})
export class QueryBuildLevelComponent implements OnInit {
  options=[
    1,2,3,4
  ];
  options2=[
    5,6,7,8
  ];
  optionSelected1:any;
  optionSelected2:any;
  constructor() { }
  @Input() list:any;
  @Input() aindex:any;
  ngOnInit() {
    console.log(this.list)
  }
 
  getCondition(){
    return {
      val1:'',
      val2:'',
      val3:'',
    }
  }
  getGroup(){
    return [];
  }
  addCondition(ruleIndex){   
      this.list.rules.push({'condition':this.getCondition()})
      const val={
        records:this.list.rules,
        index:ruleIndex
      }
     
  }
  addGroup(){
    const rules= [{'group':this.getGroup()}]    
    this.list.rules.push({'rules':rules})
    console.log(this.list);
  }
  removeCondition(i){
    this.list.rules.splice(i,1);
  }
}
