/*
 * Public API Surface of autocomplete-lib
 */

export * from './autocomplete-lib.service';
export * from './autocomplete-lib.component';
export * from './autocomplete-lib.module';
export * from './autocomplete.component'
//export * from './lib/autocomplete/highlight.pipe';

